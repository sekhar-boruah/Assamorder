import { useEffect, useState } from 'react';
import { Button, Spinner } from '../components/ui';
import { useAuth } from '../features/auth/AuthProvider';
import { supabase } from '../lib/supabase';
import type { RestaurantStatus } from '../types/db';

const STATUS_COPY: Record<RestaurantStatus, { label: string; tone: string; message: string }> = {
  pending: { label: 'Pending approval', tone: 'bg-amber-100 text-amber-800', message: 'Your restaurant is awaiting approval. We will activate it shortly.' },
  active: { label: 'Active', tone: 'bg-emerald-100 text-emerald-800', message: 'Your restaurant is live.' },
  suspended: { label: 'Suspended', tone: 'bg-red-100 text-red-800', message: 'Your restaurant is suspended. Please contact support.' },
  deactivated: { label: 'Deactivated', tone: 'bg-stone-200 text-stone-700', message: 'This restaurant has been deactivated.' },
};

export default function Dashboard() {
  const { memberships, signOut } = useAuth();
  const current = memberships[0];
  const [trialEnds, setTrialEnds] = useState<Date | null>(null);
  const [loadingSub, setLoadingSub] = useState(true);

  useEffect(() => {
    let cancelled = false;
    supabase
      .from('subscriptions')
      .select('status, trial_ends_at')
      .eq('restaurant_id', current.restaurant.id)
      .maybeSingle()
      .then(({ data }) => {
        if (cancelled) return;
        setTrialEnds(data?.status === 'trial' ? new Date(data.trial_ends_at) : null);
        setLoadingSub(false);
      });
    return () => {
      cancelled = true;
    };
  }, [current.restaurant.id]);

  if (loadingSub) return <Spinner />;

  const status = STATUS_COPY[current.restaurant.status];
  const daysLeft = trialEnds ? Math.max(0, Math.ceil((trialEnds.getTime() - Date.now()) / 86_400_000)) : null;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{current.restaurant.name}</h1>
          <p className="mt-1 text-sm text-stone-500">assamorder.in/r/{current.restaurant.slug}</p>
        </div>
        <Button variant="ghost" onClick={() => void signOut()}>Sign out</Button>
      </header>

      <section className="mt-8 rounded-2xl border border-stone-200 bg-white p-6">
        <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${status.tone}`}>{status.label}</span>
        <p className="mt-3 text-stone-700">{status.message}</p>
        {daysLeft !== null && <p className="mt-2 text-sm text-stone-500">Free trial: {daysLeft} day{daysLeft === 1 ? '' : 's'} left</p>}
      </section>
    </div>
  );
}
