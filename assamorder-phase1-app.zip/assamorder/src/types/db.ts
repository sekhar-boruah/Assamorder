export type MemberRole = 'owner' | 'manager' | 'counter' | 'kitchen';
export type RestaurantStatus = 'pending' | 'active' | 'suspended' | 'deactivated';

export interface RestaurantSummary {
  id: string;
  slug: string;
  name: string;
  status: RestaurantStatus;
}

export interface Membership {
  role: MemberRole;
  restaurant: RestaurantSummary;
}
